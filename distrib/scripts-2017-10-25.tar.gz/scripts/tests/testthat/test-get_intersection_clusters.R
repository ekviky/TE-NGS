context("intersect clusters")

gr0.gr<- GRanges(Rle(c("chr2", "chr2", "chr1", "chr3"), c(1, 3, 2, 4)),
        IRanges(1:10, width=10:1))
gr0<-as.data.frame(gr0.gr)


gr1.gr<- GRanges(Rle(c("chr2", "chr4", "chr5", "chr6"), c(1, 3, 2, 4)),
        IRanges(1:10, width=10:1))
gr1<-as.data.frame(gr1.gr)

test<-get_intersection_clusters(gr0,gr0.gr,gr1,gr1.gr)

test_that("get_intersection_clusters returns object proper fmt",{
        expect_is(test,"data.frame")
        expect_equal(nrow(test),4)
        expect_equal(ncol(test),11)
})
test_that("get_intersection_clusters finds overlap d<threshold",{
        expect_true(max(test[,which(grepl("distance",names(test))==TRUE)])<=10)
        expect_equal(max(test[,which(grepl("distance",names(test))==TRUE)]),0)
})
rm(gr0,gr0.gr,gr1,gr1.gr,test)
