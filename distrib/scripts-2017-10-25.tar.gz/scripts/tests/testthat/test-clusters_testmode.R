context("check clusters output NA12878 test mode")

test_that("clusters output file NA12878 test is identical",{
	expect_equal(dim(outfile),dim(paste0("../../../test/",outfile)))

	expected_clusters<-read.delim(paste0("../../../test/",outfile),header=TRUE)

	expect_equal(ncol(clusters_i),ncol(expected_clusters))
	expect_equal(nrow(clusters_i),nrow(expected_clusters))
	expect_equal(as.character(clusters_i[,1]),as.character(expected_clusters[,1]))
	expect_equal(clusters_i[,2],expected_clusters[,2])
	expect_equal(sum(clusters_i[,6]),sum(expected_clusters[,6]))
	rm(expected_clusters)
})
