context("convert data frame to GR object")

test_that("convert_GR returns a genomic ranges object",{
	gr0 <- GRanges(Rle(c("chr2", "chr2", "chr1", "chr3"), c(1, 3, 2, 4)),
               IRanges(1:10, width=10:1))
	a<-as.data.frame(gr0)
	
        test<-convert_GR(a)

        expect_is(test,"GRanges")
        expect_equal(length(test),nrow(a))
        rm(a,test)
})
