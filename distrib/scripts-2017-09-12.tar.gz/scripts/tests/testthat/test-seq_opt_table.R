context("check input file seq_opt_table")
test_that("seq_opt_table is proper format",{
        expect_is(miseq_table,"data.frame")
        expect_equal(ncol(miseq_table),5)
        expect_equal(names(miseq_table),c("experiment","category","TE_target_primers","TE_nested","index"))
})
