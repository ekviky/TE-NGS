context("count reads given feature")

test_that("count reads returns integer for each cluster",{
        a<-c(1,3,5,7,9,11)
        b<-list(c(1,2),c(3,4),5,c(6,8),c(9,10),11)
        test<-count_reads_given_feature(a,b)

        expect_is(test,"integer")
        expect_equal(length(test),length(b))
        expect_equal(length(na.exclude(test)),length(b))
        expect_equal(test,c(1,1,1,0,1,1))
        rm(a,b,test)
})
