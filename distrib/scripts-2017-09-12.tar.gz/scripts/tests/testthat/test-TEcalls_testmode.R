context("check TE calls output NA12878 test mode")

test_that("TE calls output file is identical",{
	expect_equal(dim(outfile2),dim(paste0("../../../test/",outfile2)))

	expected_TE<-read.delim(paste0("../../../test/",outfile2),header=TRUE)
	expect_equal(ncol(TE_calls),ncol(expected_TE))
	expect_equal(nrow(TE_calls),nrow(expected_TE))
	expect_equal(as.character(TE_calls[,1]),as.character(expected_TE[,1]))
	expect_equal(TE_calls[,2],expected_TE[,2])
	expect_equal(sum(TE_calls[,6]),sum(expected_TE[,6]))
	rm(expected_TE)
})
