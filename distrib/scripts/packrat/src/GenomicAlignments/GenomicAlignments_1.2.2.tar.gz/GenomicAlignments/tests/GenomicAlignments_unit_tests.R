BiocGenerics:::testPackage("GenomicAlignments")
