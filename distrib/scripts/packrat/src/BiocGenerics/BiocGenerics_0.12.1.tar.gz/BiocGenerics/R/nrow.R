### =========================================================================
### The nrow(), ncol(), NROW() and NCOL() generics
### -------------------------------------------------------------------------

### The corresponding functions are standard functions defined in the base
### package.

setGeneric("nrow")
setGeneric("ncol")
setGeneric("NROW")
setGeneric("NCOL")

