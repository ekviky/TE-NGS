require("XVector") || stop("unable to load XVector package")
XVector:::run_unitTests()
