.test <- function() BiocGenerics:::testPackage("S4Vectors")
