#ifndef CHECKMATE_ALL_NCHAR_H_
#define CHECKMATE_ALL_NCHAR_H_

#include <R.h>
#include <Rinternals.h>

Rboolean all_nchar(SEXP, R_len_t);

#endif
