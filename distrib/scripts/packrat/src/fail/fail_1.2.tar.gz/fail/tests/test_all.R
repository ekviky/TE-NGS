library(testthat)
library(fail)
test_package("fail")
