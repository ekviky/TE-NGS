readBfaToc <- function( bfafile )
   .Call( .readBfaToc, bfafile )
